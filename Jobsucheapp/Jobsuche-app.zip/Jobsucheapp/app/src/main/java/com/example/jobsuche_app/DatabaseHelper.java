package com.example.jobsuche_app;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import static com.example.jobsuche_app.JobsContract.JobEntry.ACTIV;
import static com.example.jobsuche_app.JobsContract.JobEntry.AUFGABE;
import static com.example.jobsuche_app.JobsContract.JobEntry.BERUFSFELD;
import static com.example.jobsuche_app.JobsContract.JobEntry.BUNDESLAND;
import static com.example.jobsuche_app.JobsContract.JobEntry.EMAIL;
import static com.example.jobsuche_app.JobsContract.JobEntry.LOGO;
import static com.example.jobsuche_app.JobsContract.JobEntry.STELLE;
import static com.example.jobsuche_app.JobsContract.JobEntry.STRASSE;

public class DatabaseHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "jobs_data";
        private static final int DATABASE_VERSION = 1;

        private final Resources mResources;
        private SQLiteDatabase mDb;
        private DatabaseHelper mDbHelper;
        private Context mContext;

        DatabaseHelper(Context context) {
            super(context,DATABASE_NAME,null,DATABASE_VERSION);
            mResources = context.getResources();
            mContext=context;
            mDb = this.getReadableDatabase();
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(JobsContract.JobEntry.JOB_TABLE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL(JobsContract.JobEntry.SQL_DELETE_ENTRIES);
            onCreate(db);
        }

        private void readDataToDb(SQLiteDatabase db){
            String jsonData = readJsonFromFile();
            try {
                JSONArray arr = new JSONArray(jsonData);
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);
                    String stelle = obj.getString("Bezeichnung der Stelle");
                    String logo = obj.getString("Logo");
                    String email = obj.getString("E-Mail");
                    String bundesland = obj.getString("Bundesland");
                    String aufgabe = obj.getString("Aufgabengebiet");
                    String strasse = obj.getString("Straße");
                    JSONArray berufsfeld = obj.getJSONArray("Berufsfeld");
                    String[] bFeldeArr = new String[berufsfeld.length()];
                    for (int j = 0; j < berufsfeld.length(); j++) {
                        bFeldeArr[i] = berufsfeld.getString(i);
                    }
                    String activ = obj.getString("Stelle aktiv bis (Publikationsende)");

                    ContentValues values = new ContentValues();
                    values.put(STELLE,stelle);
                    values.put(LOGO,logo);
                    values.put(EMAIL,email);
                    values.put(AUFGABE,aufgabe);
                    values.put(BERUFSFELD, String.valueOf(bFeldeArr));
                    values.put(STRASSE,strasse);
                    values.put(ACTIV,activ);
                    values.put(BUNDESLAND,bundesland);

                    db.insert(JobsContract.JobEntry.JOB_TABLE,null,values);
                    db.close();

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        private String readJsonFromFile(){
            InputStream is = null;
            StringBuilder sb = new StringBuilder();
            String jsonDataString = null;
            is = mResources.openRawResource(R.raw.jobs);
            try(BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is))) {
                while ((jsonDataString = bufferedReader.readLine()) != null) {
                    sb.append(jsonDataString).append('\n');
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return sb.toString();

        }
    }
