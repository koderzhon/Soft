package com.example.jobsuche_app;

public class Job {
    public static final String JOB_TABLE = "job_data";

    public static final String KEY_ROWID = "_id";
    public static final String STELLE = "stelle";
    public static final String LOGO = "logo";
    public static final String BUNDESLAND = "bundesland";
    public static final String EMAIL = "email";
    public static final String STRASSE = "strasse";
    public static final String ACTIV = "activ";
    public static final String AUFGABE = "aufgabe";
    public static final String BERUFSFELD = "berufsfeld";

    public static final String JOB_TABLE_CREATE = "create table "
            + JOB_TABLE
            + " (" + KEY_ROWID + " integer primary key autoincrement, "
            + STELLE + " text not null, "
            + LOGO + " text not null, "
            + BERUFSFELD + " text not null, "
            + AUFGABE + " text not null, "
            + ACTIV + " datetime, "
            + BUNDESLAND + " text, "
            + EMAIL + " text, "
            + STRASSE + " text)";
    public static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + JOB_TABLE;


}
